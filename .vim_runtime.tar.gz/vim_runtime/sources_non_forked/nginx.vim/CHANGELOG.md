nginx.vim CHANGELOG
=====================

This file is used to list changes made in each version of the [nginx](https://github.com/chr4/nginx.vim) plugin for the [Vim](http://www.vim.org/) editor.

1.1.0
-----

- Do not highlight `SHA` ciphers, as usage as HMAC is still considered secure

1.0.1
-----

- Highlight `gzip on` as insecure (as it might be vulnerable to BREACH/ CRIME)

1.0.0
-----

- Initial release
